const express = require('express');
const ComicBook = require('../models/comicBook');
const router = express.Router();

// Create a new comic book
router.post('/', async (req, res) => {
    try {
      const newComic = new ComicBook(req.body);
      const savedComic = await newComic.save();
      res.status(201).json({
        message: 'Comic book added successfully!',
        comicBook: savedComic,
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  

// Get all comic books
router.get('/', async (req, res) => {
    try {
      const comics = await ComicBook.find();
      res.json({
        message: 'Comic books retrieved successfully!',
        comicBooks: comics,
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  

// Get a comic book by ID
router.get('/:id', async (req, res) => {
    try {
      const comic = await ComicBook.findById(req.params.id);
      if (!comic) return res.status(404).json({ message: 'Comic not found' });
      res.json({
        message: 'Comic book retrieved successfully!',
        comicBook: comic,
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  

// Update a comic book
router.put('/:id', async (req, res) => {
    try {
      const updatedComic = await ComicBook.findByIdAndUpdate(req.params.id, req.body, { new: true });
      if (!updatedComic) return res.status(404).json({ message: 'Comic not found' });
      res.json({
        message: 'Comic book updated successfully!',
        comicBook: updatedComic,
      });
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });
  

// Delete a comic book
router.delete('/:id', async (req, res) => {
    try {
      const deletedComic = await ComicBook.findByIdAndDelete(req.params.id);
      if (!deletedComic) return res.status(404).json({ message: 'Comic not found' });
      res.json({
        message: 'Comic book deleted successfully!',
        comicBook: deletedComic,
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  

module.exports = router;
