require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const comicBookRoutes = require('./routes/comicBookRoutes');

const app = express();
app.use(express.json());  // To handle JSON data

// MongoDB connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Connected to MongoDB Atlas'))
  .catch((err) => console.log('Error connecting to MongoDB:', err));

// Routes
app.use('/api/comics', comicBookRoutes);

// Default route for handling unknown routes
app.use((req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
