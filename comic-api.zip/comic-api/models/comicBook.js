const mongoose = require('mongoose');

const comicBookSchema = new mongoose.Schema({
  bookName: { type: String, required: true },
  authorName: { type: String, required: true },
  yearOfPublication: { type: Number, required: true },
  price: { type: Number, required: true },
  discount: { type: Number, default: 0 }, // Optional
  numberOfPages: { type: Number, required: true },
  condition: { type: String, enum: ['new', 'used', 'old', 'damaged'], required: true },
  description: { type: String }, // Optional
}, { timestamps: true });

const ComicBook = mongoose.model('ComicBook', comicBookSchema);
module.exports = ComicBook;
